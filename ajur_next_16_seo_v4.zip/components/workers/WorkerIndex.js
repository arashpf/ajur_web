import React from 'react'
import PropTypes from 'prop-types'

class WorkerIndex extends React.Component {
  constructor(props) {
   super(props);
  }
  render () {
    return(
      <h2>this is index of worker</h2>
    )

  }
}

export default WorkerIndex;
