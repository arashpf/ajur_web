// pages/[categories]/[name].js
export default function Test() {
  return <h1>Simple Page</h1>
}