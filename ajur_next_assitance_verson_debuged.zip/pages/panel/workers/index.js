import React from "react"

const panelworkers = (props) => {
  return (
    <div>
        <p>pannel workers</p>
      
    </div>
  )
};

export default panelworkers;
