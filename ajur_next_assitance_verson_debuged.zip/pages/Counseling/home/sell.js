import React from 'react'
import PropTypes from 'prop-types'

const index = (props) => {
  return (
    <div>home selling counseling</div>
  )
}

export default index
