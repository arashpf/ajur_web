# Checkout template

## Usage

<!-- #default-branch-switch -->

1. Copy the files into your project, or one of the [example projects](https://github.com/mui/material-ui/tree/master/examples).
2. Make sure your project has the required dependencies: @mui/material, @emotion/styled, @emotion/react.
3. Import and use the `Checkout` component.

## Demo

<!-- #default-branch-switch -->

View the demo at https://mui.com/getting-started/templates/checkout/.
