import React from 'react'
import PropTypes from 'prop-types'

class realestateIndex extends React.Component {
  constructor(props) {
   super(props);
  }
  render () {

    return(
      <h3>realestateIndex</h3>
    )

  }
}

export default realestateIndex;
