import React from 'react'
import PropTypes from 'prop-types'

const index = (props) => {
  return (
    <div>this is worker default index</div>
  )
}

export default index
