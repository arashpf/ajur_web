import React, { useState, useEffect, useCallback } from "react";
import Styles from "../styles/WorkerMedia.module.css";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import Link from "next/link";

export default function WorkerMedia({ images = [], virtual_tours = [], videos = [] }) {
  const [activeTab, setActiveTab] = useState("images");
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [mainImageIndex, setMainImageIndex] = useState(0);
  const [thumbnailSwiperInstance, setThumbnailSwiperInstance] = useState(null);
  const [mainImageSwiperInstance, setMainImageSwiperInstance] = useState(null);
  const [isClient, setIsClient] = useState(false);

  // Initialize client-side state
  useEffect(() => {
    setIsClient(true);
  }, []);

  const openLightbox = (index) => {
    setLightboxIndex(index);
    setLightboxOpen(true);
    // prevent background scroll
    document.body.style.overflow = "hidden";
    try {
      if (typeof window !== 'undefined') {
        window.history.pushState({ ajur_lightbox: true }, '');
      }
    } catch (err) {
      console.warn('history.pushState failed', err);
    }
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    document.body.style.overflow = "";
    try {
      if (typeof window !== 'undefined' && window.history.state && window.history.state.ajur_lightbox) {
        window.history.back();
      }
    } catch (err) {
      console.warn('history.back failed', err);
    }
  };

  const showPrev = useCallback(() => {
    if (images.length > 0) {
      setLightboxIndex((i) => (i - 1 + images.length) % images.length);
    }
  }, [images.length]);

  const showNext = useCallback(() => {
    if (images.length > 0) {
      setLightboxIndex((i) => (i + 1) % images.length);
    }
  }, [images.length]);

  useEffect(() => {
    if (!lightboxOpen || !isClient) return;
    
    const onKey = (e) => {
      if (e.key === "Escape") {
        if (isFullscreen) {
          setIsFullscreen(false);
        } else {
          closeLightbox();
        }
      }
      if (e.key === "ArrowLeft") showPrev();
      if (e.key === "ArrowRight") showNext();
    };
    
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightboxOpen, showPrev, showNext, isFullscreen, isClient]);

  // Handle browser back button to close fullscreen first, then the grid modal
  useEffect(() => {
    const onPop = (e) => {
      const state = (e && e.state) || window.history.state;

      if (isFullscreen) {
        // If the new state still contains ajur_lightbox (grid), only exit fullscreen
        if (state && state.ajur_lightbox) {
          setIsFullscreen(false);
          return;
        }
        // Otherwise close everything
        setIsFullscreen(false);
        setLightboxOpen(false);
        document.body.style.overflow = "";
        return;
      }

      if (lightboxOpen) {
        // If the new state still has ajur_lightbox, keep modal open
        if (state && state.ajur_lightbox) {
          return;
        }
        setLightboxOpen(false);
        document.body.style.overflow = "";
      }
    };

    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, [isFullscreen, lightboxOpen]);

  const renderSlider = (mediaList, type) => {
    // Don't render Swiper on server-side
    if (!isClient) {
      return <div className={Styles.swiperContainer}>Loading...</div>;
    }

    // Import Swiper modules dynamically for client-side only
    const swiperConfig = {
      spaceBetween: 10,
      slidesPerView: 1,
      pagination: { 
        clickable: true,
        renderBullet: (index, className) => {
          return `<span class="${className}">${index + 1}</span>`;
        }
      },
      onSwiper: (swiper) => {
        if (type === "images") {
          setMainImageSwiperInstance(swiper);
        }
      },
      onSlideChange: (swiper) => {
        if (type === "images") {
          setMainImageIndex(swiper.activeIndex);
          // Scroll thumbnail into view when main image changes
          if (thumbnailSwiperInstance) {
            try {
              thumbnailSwiperInstance.slideTo(swiper.activeIndex);
            } catch (err) {
              console.warn("Thumbnail swiper error:", err);
            }
          }
        }
      },
      className: Styles.swiperContainer
    };

    // Add autoplay only for videos and only if on client side
    if (type === "videos" && isClient) {
      swiperConfig.autoplay = {
        delay: 3000,
        disableOnInteraction: false,
      };
    }

    return (
      <Swiper {...swiperConfig}>
        {mediaList.map((item, index) => (
          <SwiperSlide key={index}>
            {type === "images" && (
              <img
                src={item.url}
                alt={`Image ${index}`}
                className={Styles.mainImage}
                onClick={() => openLightbox(index)}
                style={{ cursor: "pointer" }}
              />
            )}
            {type === "virtual_tours" && (
              <iframe
                src={item.url}
                title={`Virtual Tour ${index}`}
                className={Styles.iframe}
                allowFullScreen
                loading="lazy"
              />
            )}
            {type === "videos" && isClient && (
              <video 
                controls 
                className={Styles.video}
                playsInline
                // Don't set autoplay here, let user control it
              >
                <source src={item.absolute_path} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            )}
          </SwiperSlide>
        ))}
      </Swiper>
    );
  };

  // Don't render interactive elements on server
  if (!isClient) {
    return (
      <div className={Styles.wrapper}>
        <div className={Styles.mediaContainer}>
          <div className={Styles.mainImageWrapper}>
            <div className={Styles.swiperContainer}>
              {images.length > 0 && (
                <img
                  src={images[0].url}
                  alt="Preview"
                  className={Styles.mainImage}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={Styles.wrapper}>
      <div className={Styles.mediaContainer}>
        {activeTab === "images" && images.length > 0 && (
          <div className={Styles.mainImageWrapper}>
            {renderSlider(images, "images")}
            {/* Pagination Indicators */}
            {images.length > 1 && (
              <div className={Styles.paginationIndicators}>
                {images.map((_, index) => (
                  <div
                    key={index}
                    className={`${Styles.indicator} ${
                      mainImageIndex === index ? Styles.active : ""
                    }`}
                    onClick={() => {
                      setMainImageIndex(index);
                      if (mainImageSwiperInstance && typeof mainImageSwiperInstance.slideTo === 'function') {
                        mainImageSwiperInstance.slideTo(index);
                      }
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        )}
        {activeTab === "virtual_tours" && virtual_tours.length > 0 && renderSlider(virtual_tours, "virtual_tours")}
        {activeTab === "videos" && videos.length > 0 && renderSlider(videos, "videos")}
      </div>

      {/* Thumbnail Carousel Below Main Image - Only show if ONLY images exist */}

      <div className={Styles.mediaBoxRow}>
        {images.length > 0 && (
          <div
            className={Styles.mediaBox}
            style={{ cursor: "pointer" }}
            onClick={() => {
              // Open the images grid modal instead of switching inline
              openLightbox(0);
              setIsFullscreen(false);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                openLightbox(0);
                setIsFullscreen(false);
              }
            }}
            role="button"
            tabIndex={0}
          >
            <div className={Styles.thumbnailContainer}>
              <img
                src={images[0]?.url}
                alt="Preview"
                className={Styles.thumbnail}
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
              <div className={Styles.mediaCounter}>{images.length} عکس</div>
            </div>
          </div>
        )}

        {virtual_tours.length > 0 && (
          <div className={Styles.mediaBox} onClick={() => setActiveTab("virtual_tours")}>
            <Link
              href={`/virtual-tour/${virtual_tours[0].worker_id}/`}
              as={`/virtual-tour/${virtual_tours[0].worker_id}/`}
              passHref
            >
              <div className={Styles.thumbnailContainer}>
                <img src={virtual_tours[0]?.thumbnail_url} alt="Preview" className={Styles.thumbnail} />
                <div className={Styles.mediaCounter}>بازدید مجازی</div>
              </div>
            </Link>
          </div>
        )}

        {videos.length > 0 && (
          <div className={Styles.mediaBox} onClick={() => setActiveTab("videos")}>
            <div className={Styles.thumbnailContainer}>
              <img src={images[1]?.url || images[0]?.url} alt="Preview" className={Styles.thumbnail} />
              <div className={Styles.mediaCounterVideo}>
                <PlayArrowIcon className={Styles.playIcon} />
              </div>
            </div>
          </div>
        )}

        {/* Empty slots to maintain 1/3 grid */}
        {images.length === 0 && (
          <div className={Styles.mediaBox} style={{ visibility: "hidden" }} />
        )}
        {virtual_tours.length === 0 && (
          <div className={Styles.mediaBox} style={{ visibility: "hidden" }} />
        )}
        {videos.length === 0 && (
          <div className={Styles.mediaBox} style={{ visibility: "hidden" }} />
        )}
      </div>

      {/* Lightbox overlay */}
      {lightboxOpen && images && images.length > 0 && (
        <div
          role="dialog"
          aria-modal="true"
          style={{
            position: "fixed",
            zIndex: 4000,
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
            background: isFullscreen ? "#000" : "#f5f5f5",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: isFullscreen ? "center" : "flex-start",
            padding: isFullscreen ? 0 : "20px",
            overflow: isFullscreen ? "hidden" : "auto",
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              if (isFullscreen) {
                setIsFullscreen(false);
              } else {
                closeLightbox();
              }
            }
          }}
        >
          {isFullscreen ? (
            <>
              {/* Fullscreen View */}
              <button
                aria-label="Exit fullscreen"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFullscreen(false);
                  try {
                    if (typeof window !== 'undefined' && window.history.state && window.history.state.ajur_lightbox_full) {
                      window.history.back();
                    }
                  } catch (err) {
                    console.warn('history.back failed', err);
                  }
                }}
                style={{
                  position: "fixed",
                  top: 20,
                  right: 20,
                  zIndex: 4002,
                  background: "#fff",
                  border: "none",
                  borderRadius: "50%",
                  width: 44,
                  height: 44,
                  cursor: "pointer",
                  fontSize: 28,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 2px 12px rgba(0,0,0,0.3)",
                }}
              >
                ×
              </button>

              {/* Fullscreen Image */}
              <img
                src={images[lightboxIndex]?.url}
                alt={`Fullscreen ${lightboxIndex}`}
                style={{
                  maxWidth: "95vw",
                  maxHeight: "95vh",
                  objectFit: "contain",
                }}
              />

              {/* Left Arrow */}
              {images.length > 1 && (
                <button
                  aria-label="Previous"
                  onClick={(e) => {
                    e.stopPropagation();
                    showPrev();
                  }}
                  style={{
                    position: "fixed",
                    left: 20,
                    top: "50%",
                    transform: "translateY(-50%)",
                    zIndex: 4002,
                    background: "rgba(255,255,255,0.9)",
                    border: "none",
                    borderRadius: 4,
                    width: 50,
                    height: 50,
                    cursor: "pointer",
                    fontSize: 28,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.2s ease",
                  }}
                  onMouseOver={(e) => {
                    e.target.style.background = "rgba(255,255,255,1)";
                    e.target.style.boxShadow = "0 4px 16px rgba(0,0,0,0.3)";
                  }}
                  onMouseOut={(e) => {
                    e.target.style.background = "rgba(255,255,255,0.9)";
                    e.target.style.boxShadow = "none";
                  }}
                >
                  ‹
                </button>
              )}

              {/* Right Arrow */}
              {images.length > 1 && (
                <button
                  aria-label="Next"
                  onClick={(e) => {
                    e.stopPropagation();
                    showNext();
                  }}
                  style={{
                    position: "fixed",
                    right: 20,
                    top: "50%",
                    transform: "translateY(-50%)",
                    zIndex: 4002,
                    background: "rgba(255,255,255,0.9)",
                    border: "none",
                    borderRadius: 4,
                    width: 50,
                    height: 50,
                    cursor: "pointer",
                    fontSize: 28,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.2s ease",
                  }}
                  onMouseOver={(e) => {
                    e.target.style.background = "rgba(255,255,255,1)";
                    e.target.style.boxShadow = "0 4px 16px rgba(0,0,0,0.3)";
                  }}
                  onMouseOut={(e) => {
                    e.target.style.background = "rgba(255,255,255,0.9)";
                    e.target.style.boxShadow = "none";
                  }}
                >
                  ›
                </button>
              )}

              {/* Bottom Counter */}
              {(videos.length > 0 || virtual_tours.length > 0) && (
                <div
                  style={{
                    position: "fixed",
                    bottom: 20,
                    left: "50%",
                    transform: "translateX(-50%)",
                    zIndex: 4002,
                    background: "rgba(0,0,0,0.6)",
                    color: "#fff",
                    padding: "10px 20px",
                    borderRadius: 4,
                    fontSize: 14,
                    fontWeight: 600,
                  }}
                >
                  {lightboxIndex + 1} / {images.length}
                </div>
              )}
            </>
          ) : (
            <>
              {/* Grid View */}
              {/* Close button */}
              <button
                aria-label="Close"
                onClick={closeLightbox}
                style={{
                  position: "fixed",
                  top: 20,
                  right: 20,
                  zIndex: 4001,
                  background: "#fff",
                  border: "none",
                  borderRadius: "50%",
                  width: 44,
                  height: 44,
                  cursor: "pointer",
                  fontSize: 28,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 2px 12px rgba(0,0,0,0.15)",
                  transition: "all 0.2s ease",
                }}
                onMouseOver={(e) => {
                  e.target.style.transform = "scale(1.1)";
                  e.target.style.boxShadow = "0 4px 16px rgba(0,0,0,0.2)";
                }}
                onMouseOut={(e) => {
                  e.target.style.transform = "scale(1)";
                  e.target.style.boxShadow = "0 2px 12px rgba(0,0,0,0.15)";
                }}
              >
                ×
              </button>

              {/* Grid View of all images - responsive large pictures */}
              <div className={Styles.gridGallery} onClick={(e) => e.stopPropagation()}>
                {images.map((img, idx) => (
                  <div
                    key={idx}
                    role="button"
                    tabIndex={0}
                    className={Styles.gridItem}
                    onClick={(e) => {
                        e.stopPropagation();
                        setLightboxIndex(idx);
                        setIsFullscreen(true);
                        try {
                          if (typeof window !== 'undefined') {
                            window.history.pushState({ ajur_lightbox_full: true }, '');
                          }
                        } catch (err) {
                          console.warn('history.pushState failed', err);
                        }
                      }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        setLightboxIndex(idx);
                        setIsFullscreen(true);
                        try {
                          if (typeof window !== 'undefined') {
                            window.history.pushState({ ajur_lightbox_full: true }, '');
                          }
                        } catch (err) {
                          console.warn('history.pushState failed', err);
                        }
                      }
                    }}
                  >
                    <img src={img.url} alt={`Image ${idx}`} className={Styles.gridImage} />
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}