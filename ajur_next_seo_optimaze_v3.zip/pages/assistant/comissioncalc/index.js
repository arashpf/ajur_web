import React from "react";
import AjurCommissionCalculator from "../../../components/commision-calculator/AjurCommissionCalculator";
import AjurCommissionPage from "../../../components/commision-calculator/AjurCommissionCalc";

function CommissionCalc() {
    return(
        <AjurCommissionPage/>
    )
}

export default CommissionCalc;