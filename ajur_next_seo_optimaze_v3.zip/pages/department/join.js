import React from "react"


const Join = (props) => {
  return (
    <div>
        <p>join section</p>
      
    </div>
  )
};

export default Join;
