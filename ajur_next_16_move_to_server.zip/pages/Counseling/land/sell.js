import React from 'react'
import PropTypes from 'prop-types'

const sell = (props) => {
  return (
    <div>this is land selling counseling page</div>
  )
}

export default sell
