import React from "react";

const FileBank = () => {
  return (
    <div className="pt-20 text-center justify-center align-middle text-lg">
      <h1 className="text-2xl font-bold">بانک فایل آجر</h1>
      <h2 className="text-xl font-semibold">!به زودی</h2>
    </div>
  );
};

export default FileBank;
