import React from 'react'
import PropTypes from 'prop-types'

class CategoryIndex extends React.Component {
  constructor(props) {
   super(props);
  }
  render () {

    return(
      <h3>index category</h3>
    )

  }
}

export default CategoryIndex;
